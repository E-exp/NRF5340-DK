/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

/** @file
 *  @brief Nordic UART Service Client sample
 */

#include <errno.h>
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/sys/printk.h>

#include "sd_mmc_start.h"
#include "ff.h"

#include <zephyr/settings/settings.h>

#include <zephyr/drivers/uart.h>

#include <zephyr/logging/log.h>

#include <drivers/include/nrfx_spim.h>
#include <drivers/include/nrfx_gpiote.h>
#include "stdio.h"
#include "string.h"
#include "support.h"
#include "ili9341.h"
uint16_t screen_pixels[320 * 240] = {(uint16_t)ILI9341_COLOR(100, 250, 250)};
uint16_t x_glob;
uint16_t y_glob;
uint16_t z_glob;
void display_update(char *notice);
#define LOG_MODULE_NAME central_uart
LOG_MODULE_REGISTER(LOG_MODULE_NAME);

char caller_id[20] = {0};
char old_string1[40] = {0};
char old_string2[40] = {0};
char old_string3[40] = {0};
char old_string4[40] = {0};
char old_string5[40] = {0};
char old_string6[40] = {0};

//--------------------- SPI section start
       #define  SCK_PIN 32 + 15
        #define MOSI_PIN 32 + 13
        #define MISO_PIN 32 + 14
nrfx_spim_t SPI4;
nrfx_spim_config_t SPI4_CFG = NRFX_SPIM_DEFAULT_CONFIG(SCK_PIN,
                                                              MOSI_PIN,
                                                              MISO_PIN,
                                                              NRF_SPIM_PIN_NOT_CONNECTED);;

nrfx_spim_t SPI3;
nrfx_spim_config_t SPI3_CFG;

nrfx_spim_xfer_desc_t SPI_Message_descr;

uint8_t spi_rd_flg = 0;
char ret_msg[4] = {55};
void SPI_wait_for_flag(void)
{
        while (1)
        {
                if (spi_rd_flg)
                {
                        break;
                }
                else
                {
                        // k_msleep(1);
                        // k_cpu_idle();
                        __asm__ volatile("nop");
                }
        }
}

void spim_handler(nrfx_spim_evt_t const *p_event, void *p_context)
{
        if (p_event->type == NRFX_SPIM_EVENT_DONE)
        {
                spi_rd_flg = 1;
        }
}
#define SPIM_INST_IDX 4
void *p_context = "Some context";



void SPI_configure(void)
{
        /*
                SPI3.p_reg = NRF_SPIM3;
                SPI3.drv_inst_idx = 0;
                SPI3_CFG.sck_pin = 32+15;
                SPI3_CFG.mosi_pin = 32+13;
                SPI3_CFG.miso_pin = 32+14;
                SPI3_CFG.ss_pin = NRFX_SPIM_PIN_NOT_USED;
                SPI3_CFG.ss_active_high = false;
                SPI3_CFG.irq_priority = 7;
                SPI3_CFG.orc = 0xFF;
                SPI3_CFG.frequency = NRF_SPIM_FREQ_500K;
                SPI3_CFG.mode = NRF_SPIM_MODE_3;
                SPI3_CFG.bit_order = NRF_SPIM_BIT_ORDER_MSB_FIRST;
                SPI3_CFG.miso_pull = NRF_GPIO_PIN_PULLUP;
                SPI3_CFG.skip_gpio_cfg = 0;
                SPI3_CFG.skip_psel_cfg = 0;
                SPI3_CFG.dcx_pin = NRFX_SPIM_PIN_NOT_USED;
                SPI3_CFG.use_hw_ss = 0;
        */
        //  nrfx_spim_init(&SPI3, &SPI3_CFG, NULL, NULL);

        SPI4.p_reg = NRF_SPIM4;
        SPI4.drv_inst_idx = 1;
        SPI4_CFG.frequency = NRFX_MHZ_TO_HZ(4);// NRF_SPIM_FREQ_4M; // NRF_SPIM_FREQ_16M;
        SPI4_CFG.mode = NRF_SPIM_MODE_3;
        SPI4_CFG.bit_order = NRF_SPIM_BIT_ORDER_MSB_FIRST;
        SPI4_CFG.miso_pull = NRF_GPIO_PIN_PULLUP;
        SPI4_CFG.skip_gpio_cfg = 0;
        SPI4_CFG.skip_psel_cfg = 0;

        nrfx_spim_init(&SPI4, &SPI4_CFG, spim_handler, NULL);

#if defined(__ZEPHYR__)
    IRQ_CONNECT(NRFX_IRQ_NUMBER_GET(NRF_SPIM_INST_GET(SPIM_INST_IDX)), IRQ_PRIO_LOWEST,
                NRFX_SPIM_INST_HANDLER_GET(SPIM_INST_IDX), 0, 0);
#endif


}
void spi_write_single(uint8_t data)
{
        uint8_t tx_data[1] = {0};
        uint8_t rx1_data[1] = {0};
        tx_data[0] = data;

        SPI_Message_descr.p_tx_buffer = tx_data;
        SPI_Message_descr.tx_length = 1;
        SPI_Message_descr.p_rx_buffer = rx1_data;
        SPI_Message_descr.rx_length = 1;
        spi_rd_flg = 0;
        nrfx_spim_xfer(&SPI4, &SPI_Message_descr, 0);
        SPI_wait_for_flag();
}
void spi_write_singleT(uint8_t data)
{
        uint8_t tx_data[1] = {0};
        uint8_t rx1_data[1] = {0};
        tx_data[0] = data;

        SPI_Message_descr.p_tx_buffer = tx_data;
        SPI_Message_descr.tx_length = 1;
        SPI_Message_descr.p_rx_buffer = rx1_data;
        SPI_Message_descr.rx_length = 1;
        spi_rd_flg = 0;
        //	nrfx_spim_xfer(&SPI3, &SPI_Message_descr, 0);
        // SPI_wait_for_flag();
}
void spi_write_multiple(uint8_t *data, uint16_t datalc)
{
        uint8_t tx_data[258] = {0};
        uint8_t rx1_data[258] = {0};
        memcpy(tx_data, data, datalc);

        SPI_Message_descr.p_tx_buffer = data;
        SPI_Message_descr.tx_length = datalc;
        SPI_Message_descr.p_rx_buffer = NULL;
        SPI_Message_descr.rx_length = datalc;
        spi_rd_flg = 0;
        nrfx_spim_xfer(&SPI4, &SPI_Message_descr, 0);
        SPI_wait_for_flag();
}

void spi_read_multiple(uint8_t *data, uint16_t datalc)
{
        uint8_t tx_data[258] = {0};
        uint8_t rx1_data[258] = {0};
        memcpy(tx_data, data, datalc);

        SPI_Message_descr.p_tx_buffer = NULL;
        SPI_Message_descr.tx_length = datalc;
        SPI_Message_descr.p_rx_buffer = data;
        SPI_Message_descr.rx_length = datalc;
        spi_rd_flg = 0;
        nrfx_spim_xfer(&SPI4, &SPI_Message_descr, 0);
        SPI_wait_for_flag();
}

void spi_read_single(uint8_t *data)
{
        uint8_t tx_data[1] = {0};
        uint8_t rx1_data[1] = {0};
        tx_data[0] = 0xFF;

        SPI_Message_descr.p_tx_buffer = tx_data;
        SPI_Message_descr.tx_length = 1;
        SPI_Message_descr.p_rx_buffer = rx1_data;
        SPI_Message_descr.rx_length = 1;
        spi_rd_flg = 0;
        nrfx_spim_xfer(&SPI4, &SPI_Message_descr, 0);
        SPI_wait_for_flag();
        *data = (uint8_t)rx1_data[0];
}
void spi_read_singleT(uint8_t *data)
{
        uint8_t tx_data[1] = {0};
        uint8_t rx1_data[1] = {0};
        tx_data[0] = 0xFF;

        SPI_Message_descr.p_tx_buffer = tx_data;
        SPI_Message_descr.tx_length = 1;
        SPI_Message_descr.p_rx_buffer = rx1_data;
        SPI_Message_descr.rx_length = 1;
        spi_rd_flg = 0;
        //	nrfx_spim_xfer(&SPI3, &SPI_Message_descr, 0);
        // SPI_wait_for_flag();
        *data = (uint8_t)rx1_data[0];
}
//--------------------- SPI section end
//--------------------- Display section start

void delay_ms(uint16_t time)
{
        k_msleep(time);
}

void GPIO_SR(uint8_t pin, uint8_t state)
{

        if (state)
        {
                nrf_gpio_pin_set(pin);
        }
        else
        {
                nrf_gpio_pin_clear(pin);
        }
}

void display_start(void)
{

        ili9341_init();
        /* Turn on the back light */
        ili9341_backlight_on();

        for (int ip = 0; ip < 320 * 240; ip++)
        {
                screen_pixels[ip] = (uint16_t)ILI9341_COLOR(0, 255, 255); // bgr 0 -bright
        }
        display_string(260, 60, "nRF53 DK CMD\0", Color_White, Color_Blue, 1);
        display_string(260, 70, "- running\0", Color_White, Color_Blue, 1);
        //	display_string(260, 80, "Click to start device Scan\0", Color_White, Color_Blue, 1);

        ili9341_set_top_left_limit(0, 0);
        ili9341_set_bottom_right_limit(320, 240);
        ili9341_bitmap_to_screen();
        k_msleep(1000);
}
#define Color_fade_1 0, 90, 90
#define Color_fade_2 0, 180, 180
#define Color_fade_3 0, 200, 200
#define Color_fade_4 0, 220, 220
#define Color_fade_5 0, 230, 230
#define Color_fade_5 0, 240, 240
#define Color_fade_6 0, 250, 250

void display_update(char *notice)
{
        // SPI_Reconfigure(0);

        for (int ip = 0; ip < 320 * 240; ip++)
        {
                screen_pixels[ip] = (uint16_t)ILI9341_COLOR(0, 255, 255); // bgr 0 -bright
        }
        display_string(260, 60, "nRF53 DK CMD\0", Color_White, Color_Blue, 1);
        if (caller_id[0] == 0)
        {
                display_string(260, 70, "- running\0", Color_White, Color_Blue, 1);
        }
        else
        {
                display_string(260, 70, caller_id, Color_White, Color_Blue, 1);
        }
        // display_string(260, 80, "Click to start device Scan\0", Color_White, Color_Blue, 1);
        display_string(260, 100, notice, Color_White, Color_Blue, 1);
        display_string(260, 110, old_string1, Color_fade_1, Color_Blue, 1);
        display_string(260, 120, old_string2, Color_fade_2, Color_Blue, 1);
        display_string(260, 130, old_string3, Color_fade_3, Color_Blue, 1);
        display_string(260, 140, old_string4, Color_fade_4, Color_Blue, 1);
        display_string(260, 150, old_string5, Color_fade_5, Color_Blue, 1);
        display_string(260, 160, old_string6, Color_fade_6, Color_Blue, 1);

        strcpy(old_string6, old_string5);
        strcpy(old_string5, old_string4);
        strcpy(old_string4, old_string3);
        strcpy(old_string3, old_string2);
        strcpy(old_string2, old_string1);
        strcpy(old_string1, notice);
        ili9341_set_top_left_limit(0, 0);
        ili9341_set_bottom_right_limit(320, 240);
        ili9341_bitmap_to_screen();
}
//--------------------- Display section end

FRESULT res;
FATFS fs;
FIL file_object;

uint8_t fatfs_write()
{
        uint8_t wrf=0;
        char test_file_name[] = "sc.txt";
        memset(&fs, 0, sizeof(FATFS));
        uint8_t drv[1] = {0};
        res = f_mount(&fs, drv, 1);

        res = f_open(&file_object, (char const *)test_file_name, FA_OPEN_ALWAYS | FA_WRITE);

        if (res == 0)
        {

                res = f_lseek(&file_object, file_object.fsize);

                uint8_t bytesrw = 0;
                TCHAR obj[] = "nRF53DK Log\n\0";
                wrf = 1;
                f_puts(obj, &file_object);
                //  f_sync(&file_object);
                f_close(&file_object);
        }
        //  f_close(&file_object);
        f_mount(0, 0, 1);
        return wrf;
}
// fatfs microsd write

void main(void)
{

        SPI_configure();
        nrf_gpio_cfg_output(32 + 11); // BL
        nrf_gpio_cfg_output(32 + 12); // lcd cs
        nrf_gpio_cfg_output(32 + 9);  // DC

        nrf_gpio_cfg_input(32 + 5, NRF_GPIO_PIN_NOPULL);
        nrf_gpio_cfg_output(32 + 6);
        nrf_gpio_pin_set(32 + 6);
        display_start();

        display_update("Modules initialized\0");
        sd_mmc_stack_init();
        uint8_t fs_answer=0;
        fs_answer = fatfs_write();
        if(fs_answer==1){
                display_update("SC.TXT write\0");}
        else{   display_update("SD not detected\0");}
        display_update("Scanning successfully started\0");
        for (;;)
        {
                if (!nrf_gpio_pin_read(32 + 5))
                {

                        display_update("Screen touch\0");
                }
        }
}
