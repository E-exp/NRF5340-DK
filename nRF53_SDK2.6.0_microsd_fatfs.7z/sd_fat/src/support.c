#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "ili9341.h"
#include "fonts.h"

ili9341_color_t logo[160];
extern uint16_t screen_pixels[320*240];
extern uint16_t x_glob;
extern uint16_t y_glob;
extern uint16_t z_glob;
extern void GPIO_SR(uint8_t pin,uint8_t state);
extern void delay_ms(uint16_t time);
extern void spi_write_singleT(uint8_t data);
extern void spi_read_singleT(uint8_t* data);

void display_set_background(uint16_t X_crd,uint16_t Y_crd,uint16_t X_cc,uint16_t Y_cc,uint8_t r,uint8_t g,uint8_t b){


	ili9341_set_top_left_limit(X_crd-X_cc, Y_crd);
	ili9341_set_bottom_right_limit(X_crd , Y_crd+Y_cc);
	ili9341_duplicate_pixel( ILI9341_COLOR(r,g,b), X_cc*Y_cc);

}



void display_print_letter(uint16_t x_crd, uint16_t y_crd, char letter,uint8_t char_r,uint8_t char_g,uint8_t char_b ,uint8_t background_r,uint8_t background_g,uint8_t background_b, uint8_t TO_BITMAP){

	uint8_t* L_tab;
	if(letter == 'A'){L_tab=L_A;}
	else if(letter == 'B'){L_tab=L_B;}
	else if(letter == 'C'){L_tab=L_C;}
	else if(letter == 'D'){L_tab=L_D;}
	else if(letter == 'E'){L_tab=L_E;}
	else if(letter == 'F'){L_tab=L_F;}
	else if(letter == 'G'){L_tab=L_G;}
	else if(letter == 'H'){L_tab=L_H;}
	else if(letter == 'I'){L_tab=L_I;}
	else if(letter == 'J'){L_tab=L_J;}
	else if(letter == 'K'){L_tab=L_K;}
	else if(letter == 'L'){L_tab=L_L;}
	else if(letter == 'M'){L_tab=L_M;}
	else if(letter == 'N'){L_tab=L_N;}
	else if(letter == 'O'){L_tab=L_O;}
	else if(letter == 'Q'){L_tab=L_Q;}
	else if(letter == 'U'){L_tab=L_U;}
	else if(letter == 'P'){L_tab=L_P;}
	else if(letter == 'R'){L_tab=L_R;}
	else if(letter == 'S'){L_tab=L_S;}
	else if(letter == 'T'){L_tab=L_T;}
	else if(letter == 'W'){L_tab=L_W;}
	else if(letter == 'Y'){L_tab=L_Y;}
	else if(letter == 'Z'){L_tab=L_Z;}
	else if(letter == 'X'){L_tab=L_X;}
	else if(letter == 'V'){L_tab=L_V;}
	
    else if(letter == 'a'){L_tab=L_a;}
	else if(letter == 'b'){L_tab=L_b;}
	else if(letter == 'c'){L_tab=L_c;}
	else if(letter == 'd'){L_tab=L_d;}
	else if(letter == 'e'){L_tab=L_e;}
	else if(letter == 'f'){L_tab=L_f;}
	else if(letter == 'g'){L_tab=L_g;}
	else if(letter == 'h'){L_tab=L_h;}
	else if(letter == 'i'){L_tab=L_i;}
	else if(letter == 'j'){L_tab=L_j;}
	else if(letter == 'k'){L_tab=L_k;}
	else if(letter == 'l'){L_tab=L_l;}
	else if(letter == 'm'){L_tab=L_m;}
	else if(letter == 'n'){L_tab=L_n;}
	else if(letter == 'o'){L_tab=L_o;}
	else if(letter == 'q'){L_tab=L_q;}
	else if(letter == 'u'){L_tab=L_u;}
	else if(letter == 'p'){L_tab=L_p;}
	else if(letter == 'r'){L_tab=L_r;}
	else if(letter == 's'){L_tab=L_s;}
	else if(letter == 't'){L_tab=L_t;}
	else if(letter == 'w'){L_tab=L_w;}
	else if(letter == 'y'){L_tab=L_y;}
	else if(letter == 'z'){L_tab=L_z;}
	else if(letter == 'x'){L_tab=L_x;}
	else if(letter == 'v'){L_tab=L_v;}    

	else if(letter == '0'){L_tab=L_0;}
	else if(letter == '1'){L_tab=L_1;}
	else if(letter == '2'){L_tab=L_2;}
	else if(letter == '3'){L_tab=L_3;}
	else if(letter == '4'){L_tab=L_4;}
	else if(letter == '5'){L_tab=L_5;}
	else if(letter == '6'){L_tab=L_6;}
	else if(letter == '7'){L_tab=L_7;}
	else if(letter == '8'){L_tab=L_8;}
	else if(letter == '9'){L_tab=L_9;}
	
	else if(letter == ':'){L_tab=L_COL;}
	else if(letter == '.'){L_tab=L_DOT;}
	else if(letter == ' '){L_tab=L_SP;}
	else if(letter == '_'){L_tab=L_LSP;}
    else if(letter == '-'){L_tab=L_MIN;}
	else if(letter == '>'){L_tab=L_RSLASH;}
	else if(letter == '='){L_tab=L_EQUAL;}
	else {L_tab=L_SP;}
	for(int j=0;j<10;j++){
        if(!TO_BITMAP){
		ili9341_set_top_left_limit(x_crd-7, y_crd+j);
		ili9341_set_bottom_right_limit(x_crd , y_crd+j );}
		for(int i=0;i<7;i++){
			//ili9341_set_top_left_limit(x_crd-i, y_crd+j);
			//ili9341_set_bottom_right_limit(x_crd-i , y_crd+j );
			if(L_tab[i+j*7]==1){
				
				//ili9341_duplicate_pixel( ILI9341_COLOR(255, 120, 255), 1UL * 1UL);
				logo[6-i] = ILI9341_COLOR(char_r, char_g, char_b);
			}
			else{
				logo[6-i] = ILI9341_COLOR(background_r, background_g, background_b);
			}
		}
        if(!TO_BITMAP){
		ili9341_copy_pixels_to_screen(logo,7);}
        else{
            for(int li=0;li<7;li++){
                screen_pixels[x_crd - 7 + li + (y_crd+j)*320]= logo[li];
            }
        }
	}

}

void display_string(uint16_t x_crd, uint16_t y_crd, char* p_string,uint8_t char_r,uint8_t char_g,uint8_t char_b,uint8_t background_r,uint8_t background_g,uint8_t background_b,uint8_t TO_BITMAP){
	
	//display_set_background(x_crd,y_crd,strlen(p_string)*7,10,background_r,background_g,background_b);
	for(int i2=0;i2<strlen(p_string);i2++){display_print_letter(x_crd-7*(i2),y_crd,p_string[i2],char_r,char_g,char_b,background_r,background_g,background_b,TO_BITMAP);}
}

uint8_t string_compare(char * s_strg, char * d_strg, uint16_t len){
	uint16_t size_source = len;
	uint8_t output = 0;
	for (int incr=0;incr<size_source;incr++)
	{
		if (s_strg[incr]==d_strg[incr])
		{
			output = 1;
		}
		else{
			output = 0;
			return output;
		}
	}
	return output;
}


void screen_xy(void){
	uint8_t xpc[4] ;
	uint8_t ypc [4];
	uint8_t zpc [4];
	uint32_t  xx=0;
	uint32_t  yy=0;
	

	if(1){
		z_glob=0;
		uint16_t zz=0;
		uint16_t cor_cc=0;

		for(int il=0;il<50;il++){
			uint16_t x0=0;
			uint16_t y0=0;
			uint8_t txd[4]={0x94,0x00,0x00,0x00};

			
			spi_write_singleT(txd[0]);
			spi_read_singleT(&ypc[1]);
			spi_read_singleT(&ypc[2]);

			txd[0] = 0xD4;

			spi_write_singleT(txd[0]);
			spi_read_singleT(&xpc[1]);
			spi_read_singleT(&xpc[2]);

			txd[0] = 0xB4;
			spi_write_singleT(txd[0]);
			spi_read_singleT(&zpc[1]);
			spi_read_singleT(&zpc[2]);
			
			x0 = xpc[1]<<8;
			x0 = x0 | xpc[2];
			x0 = x0>>4;
			
			
			y0 = ypc[1]<<8;
			y0 = y0 + ypc[2];
			y0 = y0>>4;

			zz = zpc[1]<<8;
			zz = zz | zpc[2];
			zz = zz>>4;
			
			if(zz>z_glob){z_glob=zz;}
			if(zz*6>z_glob*5){
				xx = xx +x0;
				yy = yy +y0;
				cor_cc++;
			}
		}

		uint16_t rawx;
		uint16_t rawy;
		xx = xx/cor_cc;
		yy = yy/cor_cc;
		rawx = (uint16_t)yy;
		rawy = (uint16_t)xx;
		xx-=180;
		yy-=200;
		xx = xx*240;
		yy = yy*320;
		x_glob = yy/(2000-200);
		y_glob = xx/(1890-180);
		y_glob = y_glob ; if(y_glob>65000){y_glob = 0;}
		x_glob = x_glob ; if(x_glob>65000){x_glob = 0;}


	}
	
}
