#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

uint8_t MPU_data_switch=0;
#define Color_White 0,0,0
#define Color_Blue  0  ,255  ,255

void display_set_background(uint16_t X_crd,uint16_t Y_crd,uint16_t X_cc,uint16_t Y_cc,uint8_t r,uint8_t g,uint8_t b);
void display_print_letter(uint16_t x_crd, uint16_t y_crd, char letter,uint8_t char_r,uint8_t char_g,uint8_t char_b ,uint8_t background_r,uint8_t background_g,uint8_t background_b, uint8_t TO_BITMAP);
void display_string(uint16_t x_crd, uint16_t y_crd, char* p_string,uint8_t char_r,uint8_t char_g,uint8_t char_b,uint8_t background_r,uint8_t background_g,uint8_t background_b,uint8_t TO_BITMAP);
uint8_t string_compare(char * s_strg, char * d_strg, uint16_t len);
void screen_xy(void);