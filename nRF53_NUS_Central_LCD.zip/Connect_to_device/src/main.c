/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

/** @file
 *  @brief Nordic UART Service Client sample
 */

#include <errno.h>
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/sys/printk.h>

#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>

#include <bluetooth/services/nus.h>
#include <bluetooth/services/nus_client.h>
#include <bluetooth/gatt_dm.h>
#include <bluetooth/scan.h>

#include <zephyr/settings/settings.h>

#include <zephyr/drivers/uart.h>

#include <zephyr/logging/log.h>

#include <drivers/include/nrfx_spim.h>
#include <drivers/include/nrfx_gpiote.h>
#include "stdio.h"
#include "string.h"
#include "support.h"
#include "ili9341.h"
uint16_t screen_pixels[320*240] = {(uint16_t)ILI9341_COLOR(100, 250, 250)};
 uint16_t x_glob;
 uint16_t y_glob;
 uint16_t z_glob;
void display_update(char* notice);
#define LOG_MODULE_NAME central_uart
LOG_MODULE_REGISTER(LOG_MODULE_NAME);

char caller_id[20]={0};
char old_string1[40]={0};
char old_string2[40]={0};
char old_string3[40]={0};
char old_string4[40]={0};
char old_string5[40]={0};
char old_string6[40]={0};
/* UART payload buffer element size. */
#define UART_BUF_SIZE 20

#define KEY_PASSKEY_ACCEPT DK_BTN1_MSK
#define KEY_PASSKEY_REJECT DK_BTN2_MSK

#define NUS_WRITE_TIMEOUT K_MSEC(150)
#define UART_WAIT_FOR_BUF_DELAY K_MSEC(50)
#define UART_RX_TIMEOUT 50

static const struct device *uart = DEVICE_DT_GET(DT_NODELABEL(uart0));
static struct k_work_delayable uart_work;


K_SEM_DEFINE(nus_write_sem, 0, 1);

struct uart_data_t {
	void *fifo_reserved;
	uint8_t  data[UART_BUF_SIZE];
	uint16_t len;
};

static K_FIFO_DEFINE(fifo_uart_tx_data);
static K_FIFO_DEFINE(fifo_uart_rx_data);

static struct bt_conn *default_conn;
static struct bt_nus_client nus_client;

static void ble_data_sent(struct bt_nus_client *nus, uint8_t err,
					const uint8_t *const data, uint16_t len)
{
	ARG_UNUSED(nus);

	struct uart_data_t *buf;

	/* Retrieve buffer context. */
	buf = CONTAINER_OF(data, struct uart_data_t, data);
	k_free(buf);

	k_sem_give(&nus_write_sem);

	if (err) {
		LOG_WRN("ATT error code: 0x%02X", err);
	}
}
char serv_msg[40]={0};
uint8_t serv_msg_len=0;

static uint8_t ble_data_received(struct bt_nus_client *nus,
						const uint8_t *data, uint16_t len)
{
	ARG_UNUSED(nus);

	int err;

	for (uint16_t pos = 0; pos != len;) {
		struct uart_data_t *tx = k_malloc(sizeof(*tx));

		if (!tx) {
			LOG_WRN("Not able to allocate UART send data buffer");
			return BT_GATT_ITER_CONTINUE;
		}

		/* Keep the last byte of TX buffer for potential LF char. */
		size_t tx_data_size = sizeof(tx->data) - 1;

		if ((len - pos) > tx_data_size) {
			tx->len = tx_data_size;
		} else {
			tx->len = (len - pos);
		}

		memcpy(tx->data, &data[pos], tx->len);

		pos += tx->len;

		/* Append the LF character when the CR character triggered
		 * transmission from the peer.
		 */
		if ((pos == len) && (data[len - 1] == '\r')) {
			tx->data[tx->len] = '\n';
			tx->len++;
			
		}
		if(serv_msg_len==0){
			strncpy(serv_msg,tx->data,tx->len);
			serv_msg_len+=tx->len;
			if(serv_msg[strlen(serv_msg)-1]=='\n'){
				if(strlen(serv_msg)<40){ serv_msg[strlen(serv_msg)]=='\0';}
				display_update(serv_msg);
				serv_msg_len=0;
				memset(serv_msg,0,40);
			}
		}
		else{
			strncat(serv_msg,tx->data,tx->len);
			serv_msg_len+=tx->len;
			if(serv_msg[strlen(serv_msg)-1]=='\n'){
				if(strlen(serv_msg)<40){ serv_msg[strlen(serv_msg)]=='\0';}
				display_update(serv_msg);
				serv_msg_len=0;
				memset(serv_msg,0,40);
			}
		}
		
		err = uart_tx(uart, tx->data, tx->len, SYS_FOREVER_MS);
		if (err) {
			k_fifo_put(&fifo_uart_tx_data, tx);
		}
	}

	return BT_GATT_ITER_CONTINUE;
}

static void uart_cb(const struct device *dev, struct uart_event *evt, void *user_data)
{
	ARG_UNUSED(dev);

	static size_t aborted_len;
	struct uart_data_t *buf;
	static uint8_t *aborted_buf;
	static bool disable_req;

	switch (evt->type) {
	case UART_TX_DONE:
		LOG_DBG("UART_TX_DONE");
		if ((evt->data.tx.len == 0) ||
		    (!evt->data.tx.buf)) {
			return;
		}

		if (aborted_buf) {
			buf = CONTAINER_OF(aborted_buf, struct uart_data_t,
					   data);
			aborted_buf = NULL;
			aborted_len = 0;
		} else {
			buf = CONTAINER_OF(evt->data.tx.buf,
					   struct uart_data_t,
					   data);
		}

		k_free(buf);

		buf = k_fifo_get(&fifo_uart_tx_data, K_NO_WAIT);
		if (!buf) {
			return;
		}

		if (uart_tx(uart, buf->data, buf->len, SYS_FOREVER_MS)) {
			LOG_WRN("Failed to send data over UART");
		}

		break;

	case UART_RX_RDY:
		LOG_DBG("UART_RX_RDY");
		buf = CONTAINER_OF(evt->data.rx.buf, struct uart_data_t, data);
		buf->len += evt->data.rx.len;

		if (disable_req) {
			return;
		}

		if ((evt->data.rx.buf[buf->len - 1] == '\n') ||
		    (evt->data.rx.buf[buf->len - 1] == '\r')) {
			disable_req = true;
			uart_rx_disable(uart);
			//display_update((char*)evt->data.rx.buf);
			
		}

		break;

	case UART_RX_DISABLED:
		LOG_DBG("UART_RX_DISABLED");
		disable_req = false;

		buf = k_malloc(sizeof(*buf));
		if (buf) {
			buf->len = 0;
		} else {
			LOG_WRN("Not able to allocate UART receive buffer");
			k_work_reschedule(&uart_work, UART_WAIT_FOR_BUF_DELAY);
			return;
		}

		uart_rx_enable(uart, buf->data, sizeof(buf->data),
			       UART_RX_TIMEOUT);

		break;

	case UART_RX_BUF_REQUEST:
		LOG_DBG("UART_RX_BUF_REQUEST");
		buf = k_malloc(sizeof(*buf));
		if (buf) {
			buf->len = 0;
			uart_rx_buf_rsp(uart, buf->data, sizeof(buf->data));
		} else {
			LOG_WRN("Not able to allocate UART receive buffer");
		}

		break;

	case UART_RX_BUF_RELEASED:
		LOG_DBG("UART_RX_BUF_RELEASED");
		buf = CONTAINER_OF(evt->data.rx_buf.buf, struct uart_data_t,
				   data);

		if (buf->len > 0) {
			k_fifo_put(&fifo_uart_rx_data, buf);
		} else {
			k_free(buf);
		}

		break;

	case UART_TX_ABORTED:
		LOG_DBG("UART_TX_ABORTED");
		if (!aborted_buf) {
			aborted_buf = (uint8_t *)evt->data.tx.buf;
		}

		aborted_len += evt->data.tx.len;
		buf = CONTAINER_OF(aborted_buf, struct uart_data_t,
				   data);

		uart_tx(uart, &buf->data[aborted_len],
			buf->len - aborted_len, SYS_FOREVER_MS);

		break;

	default:
		break;
	}
}

static void uart_work_handler(struct k_work *item)
{
	struct uart_data_t *buf;

	buf = k_malloc(sizeof(*buf));
	if (buf) {
		buf->len = 0;
	} else {
		LOG_WRN("Not able to allocate UART receive buffer");
		k_work_reschedule(&uart_work, UART_WAIT_FOR_BUF_DELAY);
		return;
	}

	uart_rx_enable(uart, buf->data, sizeof(buf->data), UART_RX_TIMEOUT);
}

static int uart_init(void)
{
	int err;
	struct uart_data_t *rx;

	if (!device_is_ready(uart)) {
		LOG_ERR("UART device not ready");
		return -ENODEV;
	}

	rx = k_malloc(sizeof(*rx));
	if (rx) {
		rx->len = 0;
	} else {
		return -ENOMEM;
	}

	k_work_init_delayable(&uart_work, uart_work_handler);

	err = uart_callback_set(uart, uart_cb, NULL);
	if (err) {
		return err;
	}

	return uart_rx_enable(uart, rx->data, sizeof(rx->data),
			      UART_RX_TIMEOUT);
}

static void discovery_complete(struct bt_gatt_dm *dm,
			       void *context)
{
	struct bt_nus_client *nus = context;
	LOG_INF("Service discovery completed");

	bt_gatt_dm_data_print(dm);

	bt_nus_handles_assign(dm, nus);
	bt_nus_subscribe_receive(nus);

	bt_gatt_dm_data_release(dm);
}

static void discovery_service_not_found(struct bt_conn *conn,
					void *context)
{
	LOG_INF("Service not found");
}

static void discovery_error(struct bt_conn *conn,
			    int err,
			    void *context)
{
	LOG_WRN("Error while discovering GATT database: (%d)", err);
}

struct bt_gatt_dm_cb discovery_cb = {
	.completed         = discovery_complete,
	.service_not_found = discovery_service_not_found,
	.error_found       = discovery_error,
};

static void gatt_discover(struct bt_conn *conn)
{
	int err;

	if (conn != default_conn) {
		return;
	}

	err = bt_gatt_dm_start(conn,
			       BT_UUID_NUS_SERVICE,
			       &discovery_cb,
			       &nus_client);
	if (err) {
		LOG_ERR("could not start the discovery procedure, error "
			"code: %d", err);
	}
}

static void exchange_func(struct bt_conn *conn, uint8_t err, struct bt_gatt_exchange_params *params)
{
	if (!err) {
		LOG_INF("MTU exchange done");
	} else {
		LOG_WRN("MTU exchange failed (err %" PRIu8 ")", err);
	}
}

static void connected(struct bt_conn *conn, uint8_t conn_err)
{
	char addr[BT_ADDR_LE_STR_LEN];
	int err;

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (conn_err) {
		LOG_INF("Failed to connect to %s (%d)", addr, conn_err);

		if (default_conn == conn) {
			bt_conn_unref(default_conn);
			default_conn = NULL;

			err = bt_scan_start(BT_SCAN_TYPE_SCAN_ACTIVE);
			if (err) {
				LOG_ERR("Scanning failed to start (err %d)",
					err);
			}
		}

		return;
	}

	LOG_INF("Connected: %s", addr);

	static struct bt_gatt_exchange_params exchange_params;

	exchange_params.func = exchange_func;
	err = bt_gatt_exchange_mtu(conn, &exchange_params);
	if (err) {
		LOG_WRN("MTU exchange failed (err %d)", err);
	}

	err = bt_conn_set_security(conn, BT_SECURITY_L2);
	if (err) {
		LOG_WRN("Failed to set security: %d", err);

		gatt_discover(conn);
	}

	err = bt_scan_stop();
	if ((!err) && (err != -EALREADY)) {
		LOG_ERR("Stop LE scan failed (err %d)", err);
	}
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	char addr[BT_ADDR_LE_STR_LEN];
	int err;

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Disconnected: %s (reason %u)", addr, reason);

	strcpy(caller_id,"No device\0");
	display_update("Disconnected\0");
	if (default_conn != conn) {
		return;
	}

	bt_conn_unref(default_conn);
	default_conn = NULL;

	err = bt_scan_start(BT_SCAN_TYPE_SCAN_ACTIVE);
	if (err) {
		LOG_ERR("Scanning failed to start (err %d)",
			err);
	}
}

static void security_changed(struct bt_conn *conn, bt_security_t level,
			     enum bt_security_err err)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (!err) {
		LOG_INF("Security changed: %s level %u", addr, level);
	} else {
		LOG_WRN("Security failed: %s level %u err %d", addr,
			level, err);
	}

	gatt_discover(conn);
}

BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected = connected,
	.disconnected = disconnected,
	.security_changed = security_changed
};

static void scan_filter_match(struct bt_scan_device_info *device_info,
			      struct bt_scan_filter_match *filter_match,
			      bool connectable)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(device_info->recv_info->addr, addr, sizeof(addr));

	LOG_INF("Filters matched. Address: %s connectable: %d",
		addr, connectable);
		
		strncpy(caller_id,addr,19);
		display_update("Connecting...\0");
}

static void scan_connecting_error(struct bt_scan_device_info *device_info)
{
	LOG_WRN("Connecting failed");
}

static void scan_connecting(struct bt_scan_device_info *device_info,
			    struct bt_conn *conn)
{
	default_conn = bt_conn_ref(conn);
}

static int nus_client_init(void)
{
	int err;
	struct bt_nus_client_init_param init = {
		.cb = {
			.received = ble_data_received,
			.sent = ble_data_sent,
		}
	};

	err = bt_nus_client_init(&nus_client, &init);
	if (err) {
		LOG_ERR("NUS Client initialization failed (err %d)", err);
		return err;
	}

	LOG_INF("NUS Client module initialized");
	return err;
}

BT_SCAN_CB_INIT(scan_cb, scan_filter_match, NULL,
		scan_connecting_error, scan_connecting);

static int scan_init(void)
{
	int err;
	struct bt_scan_init_param scan_init = {
		.connect_if_match = 1,
	};

	bt_scan_init(&scan_init);
	bt_scan_cb_register(&scan_cb);

	err = bt_scan_filter_add(BT_SCAN_FILTER_TYPE_UUID, BT_UUID_NUS_SERVICE);
	if (err) {
		LOG_ERR("Scanning filters cannot be set (err %d)", err);
		return err;
	}

	err = bt_scan_filter_enable(BT_SCAN_UUID_FILTER, false);
	if (err) {
		LOG_ERR("Filters cannot be turned on (err %d)", err);
		return err;
	}

	LOG_INF("Scan module initialized");
	return err;
}


static void auth_cancel(struct bt_conn *conn)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Pairing cancelled: %s", addr);
}


static void pairing_complete(struct bt_conn *conn, bool bonded)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_INF("Pairing completed: %s, bonded: %d", addr, bonded);
}


static void pairing_failed(struct bt_conn *conn, enum bt_security_err reason)
{
	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	LOG_WRN("Pairing failed conn: %s, reason %d", addr, reason);
}

static struct bt_conn_auth_cb conn_auth_callbacks = {
	.cancel = auth_cancel,
};

static struct bt_conn_auth_info_cb conn_auth_info_callbacks = {
	.pairing_complete = pairing_complete,
	.pairing_failed = pairing_failed
};

//--------------------- SPI section start
nrfx_spim_t SPI4;
nrfx_spim_config_t SPI4_CFG;


nrfx_spim_xfer_desc_t SPI_Message_descr;

uint8_t spi_rd_flg = 0;
char ret_msg[4] = {55};
void SPI_wait_for_flag(void)
{
	while (1)
	{
		if (spi_rd_flg)
		{
			break;
		}
		else
		{
			// k_msleep(1);
			// k_cpu_idle();
			__asm__ volatile("nop");
		}
	}
}

void spim_handler(nrfx_spim_evt_t const *p_event, void *p_context)
{
	if (p_event->type == NRFX_SPIM_EVENT_DONE)
	{
		spi_rd_flg = 1;
	}
}
#define SPIM_INST_IDX 4
void *p_context = "Some context";

void SPI_Reconfigure(uint8_t cfg_type){
	nrfx_spim_uninit(&SPI4);
	if(cfg_type==1){
		// cfg for the touch controller
		SPI4_CFG.ss_pin = 32+6;
		SPI4_CFG.frequency = NRF_SPIM_FREQ_2M;
	}
	else{
		SPI4_CFG.ss_pin = 32+12;
		SPI4_CFG.frequency = NRF_SPIM_FREQ_16M;
	}


	nrfx_spim_init(&SPI4, &SPI4_CFG, spim_handler, NULL);

	#if defined(__ZEPHYR__)
	#define SPIM_INST NRFX_CONCAT_2(NRF_SPIM, SPIM_INST_IDX)
	#define SPIM_INST_HANDLER NRFX_CONCAT_3(nrfx_spim_, SPIM_INST_IDX, _irq_handler)
		IRQ_DIRECT_CONNECT(NRFX_IRQ_NUMBER_GET(SPIM_INST), IRQ_PRIO_LOWEST, SPIM_INST_HANDLER, 0);
	#endif	
}

void SPI_configure(void)
{
	
	SPI4.p_reg = NRF_SPIM4;
	SPI4.drv_inst_idx = 0;
	SPI4_CFG.sck_pin = 32+15;
	SPI4_CFG.mosi_pin = 32+13;
	SPI4_CFG.miso_pin = 32+14;
	SPI4_CFG.ss_pin = 32+12;
	SPI4_CFG.ss_active_high = false;
	SPI4_CFG.irq_priority = 7;
	SPI4_CFG.orc = 0xFF;
	SPI4_CFG.frequency = NRF_SPIM_FREQ_16M;
	SPI4_CFG.mode = NRF_SPIM_MODE_3;
	SPI4_CFG.bit_order = NRF_SPIM_BIT_ORDER_MSB_FIRST;
	SPI4_CFG.miso_pull = NRF_GPIO_PIN_PULLUP;
	SPI4_CFG.skip_gpio_cfg = 0;
	SPI4_CFG.skip_psel_cfg = 0;
	SPI4_CFG.dcx_pin = NRFX_SPIM_PIN_NOT_USED;
	SPI4_CFG.use_hw_ss = 0;



	nrfx_spim_init(&SPI4, &SPI4_CFG, spim_handler, NULL);

#if defined(__ZEPHYR__)
#define SPIM_INST NRFX_CONCAT_2(NRF_SPIM, SPIM_INST_IDX)
#define SPIM_INST_HANDLER NRFX_CONCAT_3(nrfx_spim_, SPIM_INST_IDX, _irq_handler)
	IRQ_DIRECT_CONNECT(NRFX_IRQ_NUMBER_GET(SPIM_INST), IRQ_PRIO_LOWEST, SPIM_INST_HANDLER, 0);
#endif



}
void spi_write_single(uint8_t data)
{
	uint8_t tx_data[1] = {0};
	uint8_t rx1_data[1] = {0};
	tx_data[0] = data;

	SPI_Message_descr.p_tx_buffer = tx_data;
	SPI_Message_descr.tx_length = 1;
	SPI_Message_descr.p_rx_buffer = rx1_data;
	SPI_Message_descr.rx_length = 1;
	spi_rd_flg = 0;
	nrfx_spim_xfer(&SPI4, &SPI_Message_descr, 0);
	SPI_wait_for_flag();
}
void spi_write_singleT(uint8_t data)
{
	uint8_t tx_data[1] = {0};
	uint8_t rx1_data[1] = {0};
	tx_data[0] = data;

	SPI_Message_descr.p_tx_buffer = tx_data;
	SPI_Message_descr.tx_length = 1;
	SPI_Message_descr.p_rx_buffer = rx1_data;
	SPI_Message_descr.rx_length = 1;
	spi_rd_flg = 0;
//	nrfx_spim_xfer(&SPI3, &SPI_Message_descr, 0);
	//SPI_wait_for_flag();
}
void spi_write_multiple(uint8_t *data, uint16_t datalc)
{
	uint8_t tx_data[258] = {0};
	uint8_t rx1_data[258] = {0};
	memcpy(tx_data, data, datalc);

	SPI_Message_descr.p_tx_buffer = tx_data;
	SPI_Message_descr.tx_length = datalc;
	SPI_Message_descr.p_rx_buffer = rx1_data;
	SPI_Message_descr.rx_length = datalc;
	spi_rd_flg = 0;
	nrfx_spim_xfer(&SPI4, &SPI_Message_descr, 0);
	SPI_wait_for_flag();
}

void spi_read_single(uint8_t *data)
{
	uint8_t tx_data[1] = {0};
	uint8_t rx1_data[1] = {0};
	tx_data[0] = 0xFF;

	SPI_Message_descr.p_tx_buffer = tx_data;
	SPI_Message_descr.tx_length = 1;
	SPI_Message_descr.p_rx_buffer = rx1_data;
	SPI_Message_descr.rx_length = 1;
	spi_rd_flg = 0;
	nrfx_spim_xfer(&SPI4, &SPI_Message_descr, 0);
	SPI_wait_for_flag();
	*data = (uint8_t)rx1_data[0];
}
void spi_read_singleT(uint8_t *data)
{
	uint8_t tx_data[1] = {0};
	uint8_t rx1_data[1] = {0};
	tx_data[0] = 0xFF;

	SPI_Message_descr.p_tx_buffer = tx_data;
	SPI_Message_descr.tx_length = 1;
	SPI_Message_descr.p_rx_buffer = rx1_data;
	SPI_Message_descr.rx_length = 1;
	spi_rd_flg = 0;
//	nrfx_spim_xfer(&SPI3, &SPI_Message_descr, 0);
	//SPI_wait_for_flag();
	*data = (uint8_t)rx1_data[0];
}
//--------------------- SPI section end
//--------------------- Display section start

void delay_ms(uint16_t time)
{
	k_msleep(time);
}

void GPIO_SR(uint8_t pin, uint8_t state)
{

	if (state)
	{
		nrf_gpio_pin_set(pin);
	}
	else
	{
		nrf_gpio_pin_clear(pin);
	}
}

void display_start(void)
{

	ili9341_init();
	/* Turn on the back light */
	ili9341_backlight_on();


	for (int ip = 0; ip < 320 * 240; ip++)
	{
		screen_pixels[ip] = (uint16_t)ILI9341_COLOR(0, 255, 255); // bgr 0 -bright
	}
	display_string(260, 60, "List of BLE devices:\0", Color_White, Color_Blue, 1);
	display_string(260, 70, "- no scan started\0", Color_White, Color_Blue, 1);
//	display_string(260, 80, "Click to start device Scan\0", Color_White, Color_Blue, 1);

	ili9341_set_top_left_limit(0, 0);
	ili9341_set_bottom_right_limit(320, 240);
	ili9341_bitmap_to_screen();
	k_msleep(1000);
}
#define Color_fade_1 0,90,90
#define Color_fade_2 0,180,180
#define Color_fade_3 0,200,200
#define Color_fade_4 0,220,220
#define Color_fade_5 0,230,230
#define Color_fade_5 0,240,240
#define Color_fade_6 0,250,250

void display_update(char* notice)
{
	//SPI_Reconfigure(0);

	for (int ip = 0; ip < 320 * 240; ip++)
	{
		screen_pixels[ip] = (uint16_t)ILI9341_COLOR(0, 255, 255); // bgr 0 -bright
	}
	display_string(260, 60, "List of BLE devices:\0", Color_White, Color_Blue, 1);
	if(caller_id[0]==0){display_string(260, 70, "- not detected\0", Color_White, Color_Blue, 1);}
	else{display_string(260, 70, caller_id, Color_White, Color_Blue, 1);}
	//display_string(260, 80, "Click to start device Scan\0", Color_White, Color_Blue, 1);
	display_string(260, 100, notice, Color_White, Color_Blue, 1);
	display_string(260, 110, old_string1, Color_fade_1, Color_Blue, 1);
	display_string(260, 120, old_string2, Color_fade_2, Color_Blue, 1);
	display_string(260, 130, old_string3, Color_fade_3, Color_Blue, 1);
	display_string(260, 140, old_string4, Color_fade_4, Color_Blue, 1);
	display_string(260, 150, old_string5, Color_fade_5, Color_Blue, 1);
	display_string(260, 160, old_string6, Color_fade_6, Color_Blue, 1);

	strcpy(old_string6,old_string5);
	strcpy(old_string5,old_string4);	
	strcpy(old_string4,old_string3);	
	strcpy(old_string3,old_string2);
	strcpy(old_string2,old_string1);
	strcpy(old_string1,notice);
	ili9341_set_top_left_limit(0, 0);
	ili9341_set_bottom_right_limit(320, 240);
	ili9341_bitmap_to_screen();

}
//--------------------- Display section end

void main(void)
{

		SPI_configure();
			nrf_gpio_cfg_output(32+11); //BL
	nrf_gpio_cfg_output(32+9); //DC
	//nrf_gpio_pin_dir_set(32+5,NRF_GPIO_PIN_DIR_INPUT);
	nrf_gpio_cfg_input(32+5,NRF_GPIO_PIN_NOPULL);
	nrf_gpio_cfg_output(32+6);
	nrf_gpio_pin_set(32+6);
	display_start();
	//screen_xy();

	int err;

	err = bt_conn_auth_cb_register(&conn_auth_callbacks);
	if (err) {
		LOG_ERR("Failed to register authorization callbacks.");
		return;
	}

	err = bt_conn_auth_info_cb_register(&conn_auth_info_callbacks);
	if (err) {
		printk("Failed to register authorization info callbacks.\n");
		return;
	}

	err = bt_enable(NULL);
	if (err) {
		LOG_ERR("Bluetooth init failed (err %d)", err);
		return;
	}
	LOG_INF("Bluetooth initialized");
	display_update("Bluetooth initialized\0");

	if (IS_ENABLED(CONFIG_SETTINGS)) {
		settings_load();
	}

	int (*module_init[])(void) = {uart_init, scan_init, nus_client_init};
	for (size_t i = 0; i < ARRAY_SIZE(module_init); i++) {
		err = (*module_init[i])();
		if (err) {
			return;
		}
	}

	printk("Starting Bluetooth Central UART example\n");


	err = bt_scan_start(BT_SCAN_TYPE_SCAN_ACTIVE);
	if (err) {
		LOG_ERR("Scanning failed to start (err %d)", err);
		return;
	}

	LOG_INF("Scanning successfully started");
	display_update("Scanning successfully started\0");
	for (;;) {
		if(!nrf_gpio_pin_read(32+5)){
			//SPI_Reconfigure(1);
			//screen_xy();
			//if((x_glob>250)&(y_glob<100)){
				display_update("Screen touch\0");
			//}
		}
		/* Wait indefinitely for data to be sent over Bluetooth */
		struct uart_data_t *buf = k_fifo_get(&fifo_uart_rx_data,
						     K_FOREVER);

		err = bt_nus_client_send(&nus_client, buf->data, buf->len);
		if (err) {
			LOG_WRN("Failed to send data over BLE connection"
				"(err %d)", err);
		}

		err = k_sem_take(&nus_write_sem, NUS_WRITE_TIMEOUT);
		if (err) {
			LOG_WRN("NUS send timeout");
		}
	}
}
